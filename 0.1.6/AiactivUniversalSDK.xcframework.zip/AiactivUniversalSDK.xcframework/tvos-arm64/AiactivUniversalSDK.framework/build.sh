rm -rf ./build/*

xcodebuild archive -scheme AiactivUniversalSDK -configuration Release -destination 'generic/platform=iOS' -archivePath './build/AiactivUniversalSDK.framework-iphoneos.xcarchive' SKIP_INSTALL=NO BUILD_LIBRARIES_FOR_DISTRIBUTION=YES

xcodebuild archive -scheme AiactivUniversalSDK -configuration Release -destination 'generic/platform=iOS Simulator' -archivePath './build/AiactivUniversalSDK.framework-iphonesimulator.xcarchive' SKIP_INSTALL=NO BUILD_LIBRARIES_FOR_DISTRIBUTION=YES

xcodebuild archive -scheme AiactivUniversalSDK -configuration Release -sdk appletvos16.4 -archivePath './build/AiactivUniversalSDK.framework-appletvos.xcarchive' SKIP_INSTALL=NO BUILD_LIBRARIES_FOR_DISTRIBUTION=YES

xcodebuild archive -scheme AiactivUniversalSDK -configuration Release -sdk appletvsimulator16.4 -archivePath './build/AiactivUniversalSDK.framework-appletvsimulator.xcarchive' SKIP_INSTALL=NO BUILD_LIBRARIES_FOR_DISTRIBUTION=YES

xcodebuild -create-xcframework -framework './build/AiactivUniversalSDK.framework-iphoneos.xcarchive/Products/Library/Frameworks/AiactivUniversalSDK.framework' -framework './build/AiactivUniversalSDK.framework-iphonesimulator.xcarchive/Products/Library/Frameworks/AiactivUniversalSDK.framework' -framework './build/AiactivUniversalSDK.framework-appletvos.xcarchive/Products/Library/Frameworks/AiactivUniversalSDK.framework'  -framework './build/AiactivUniversalSDK.framework-appletvsimulator.xcarchive/Products/Library/Frameworks/AiactivUniversalSDK.framework' -output './build/AiactivUniversalSDK.xcframework'
